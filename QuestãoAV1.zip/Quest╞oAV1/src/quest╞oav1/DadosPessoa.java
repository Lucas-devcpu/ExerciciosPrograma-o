/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questãoav1;

import java.util.ArrayList;

/**
 *
 * @author 201803095601
 */
public class DadosPessoa {
  public static  ArrayList ListaPessoa = new ArrayList();
    private String nome;
    private int sexo;
    private int peso;
    private int idade;
    private double altura;
    
    public DadosPessoa () {
     }
    
    public DadosPessoa(String nome, int sexo, int peso, int idade, Double altura){
        this.nome = nome;
        this.altura = altura;
        this.idade = idade;
        this.sexo = sexo;
        this.peso = peso;
    }

    public static ArrayList getListaPessoa() {
        return ListaPessoa;
    }

    public static void setListaPessoa(ArrayList ListaPessoa) {
        DadosPessoa.ListaPessoa = ListaPessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getSexo() {
        return sexo;
    }

    public void setSexo(int sexo) {
        this.sexo = sexo;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public void InserirPaciente (DadosPessoa pPacienteCadastrado){
        try {
            DadosPessoa.ListaPessoa.add(pPacienteCadastrado);
        } catch (Exception e) {
            System.out.println("ERRO: " + e.getMessage());
        }
    }
}
